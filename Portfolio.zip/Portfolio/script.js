function toggleDarkMode() {
    var body = document.body;
    body.classList.toggle("dark-mode");
}

// document.getElementById("toggleButton").addEventListener("click", toggleDarkMode);
